// config.js
window.APP_CONFIG = {
  CLIENT_ID: "PASTE_YOUR_CLIENT_ID.apps.googleusercontent.com",
  CALENDAR_ID: "primary",       // recommended: set to your "KG Demolish" calendar id
  DEFAULT_FILTER: "#KG",
  DEFAULT_DURATION_MIN: 120,
  TITLE_PREFIX: "KG "
};
